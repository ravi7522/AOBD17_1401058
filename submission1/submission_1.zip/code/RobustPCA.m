function [L, S] = RobustPCA(X, lambda, mu, tol, max_iter)

    [M, N] = size(X);
    unobserved = isnan(X);
    X(unobserved) = 0;
    normX = norm(X, 'fro');

    if nargin < 2
        lambda = 1 / sqrt(max(M,N));
    end
    if nargin < 3
        mu = (M .* N)./4 * norm(M,1);
    end
    if nargin < 4
        tol = 1e-7;
    end
    if nargin < 5
        max_iter = 1000;
    end
    
    % initial solution
    L = zeros(M, N);
    S = zeros(M, N);
    Y = zeros(M, N);
    
    for iter = (1:max_iter)
        % update L and S
        L = Do(1/mu, X - S + (1/mu)*Y);
        S = So(lambda/mu, X - L + (1/mu)*Y);
        % augmented lagrangian multiplier
        Z = X - L - S;
        Z(unobserved) = 0;
        Y = Y + mu*Z;
        
        err = norm(Z, 'fro') / normX;
        if (iter == 1) || (mod(iter, 10) == 0) || (err < tol)
            fprintf(1, 'iter: %04d\terr: %f\trank(L): %d\tcard(S): %d\n', ...
                    iter, err, rank(L), nnz(S(~unobserved)));
        end
        if (err < tol) break; end
    end
end

% shrinkage operator
function r = So(tau, X)    
    r = sign(X) .* max(abs(X) - tau, 0);
end

% shrinkage operator for singular values
function r = Do(tau, X)
    [U, S, V] = svd(X, 'econ');
    r = U*So(tau, S)*V';
end
